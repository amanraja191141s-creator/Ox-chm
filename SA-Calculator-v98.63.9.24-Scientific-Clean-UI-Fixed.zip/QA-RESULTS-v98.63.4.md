# QA results — v98.63.4

- Automated tests: **364 passed, 0 failed** (`npm test`).
- Android web bundle: **passed** (`npm run build:web`; 34 required assets checked; 22 CSS source layers consolidated).
- JavaScript syntax: **passed** (`node --check assets/js/app.js`).
- Production copy consistency: **passed** (`index.html`, `assets/js/app.js`, and `assets/css/app.css` match their `www/` copies).
- YAML syntax: **passed**.
- ZIP integrity: **passed** (`unzip -t`).

Focused screenshot regression coverage:
1. Bottom dock no longer adds an extra CSS safe-area band below its 68px layout height.
2. Currency picker heading is bounded; searchable currency options render as vertically stacked, full-width rows. Native fallback option labels use `CODE — Currency name`.
3. The exchange-rate quote remains visible while duplicate status and refresh-time lines are visually hidden but retained for assistive technology.
4. The Convert action remains visible and touch-sized.

Physical Android validation is still required to confirm exact rendering and native WebView inset behavior on the user's device.
