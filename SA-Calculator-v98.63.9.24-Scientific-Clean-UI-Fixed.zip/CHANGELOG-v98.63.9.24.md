# Changelog — v98.63.9.24

- Reworked the scientific drawer to match the supplied reference recording: flat pink panel, unboxed text-only scientific keys, no helper captions/display strip above or below the keys, and a separate dark circular More control.
- Removed card borders, key backgrounds, rounded key tiles, and per-key shadows from both the primary and expanded scientific function grids.
- Kept the 4×4 primary function matrix, INV state, More/expanded functions, existing data attributes, and JavaScript insertion/action handlers intact.
- Kept keyboard focus indication and minimum 48px touch targets.
- Preserved the main calculator keypad, calculation engine, scientific parser and tool destinations.
