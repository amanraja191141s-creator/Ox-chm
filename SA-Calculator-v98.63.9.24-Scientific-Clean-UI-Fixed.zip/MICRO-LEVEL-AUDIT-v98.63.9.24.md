# Micro-level audit — v98.63.9.24

## Reference observations
The supplied 17.93-second recording shows a flat pink scientific-function surface, plain labels without individual button cards or borders, no explanatory text above/below the function matrix, and a dark circular plus control. The regular calculator keypad remains visually separate; only a narrow pink edge is visible when the scientific panel is closed.

## Source-level corrections
- Final-cascade overrides remove borders, tile backgrounds, radii and shadows from all primary scientific function keys.
- Scientific display/toolbar/angle/close elements are visually suppressed in the overlay so the function surface stays clean and uncluttered. Angle preference and calculation state remain in the runtime; angle mode can still be configured from calculator settings.
- Primary matrix remains 4 columns × 4 rows; INV and More remain active.
- Expanded functions use the same flat pink/text-only visual language.
- More remains a separate dark circular floating control.
- Touch target minimum and keyboard focus indication are retained.
- Main calculator keypad, calculation engine, scientific parser, tool destinations and action handlers were not rewritten.

## QA
- `npm test`: 47/47 passed.
- `npm run build:web`: passed; 13 required assets verified.
- JavaScript syntax checks and workflow YAML parse: passed.

## Scope and limits
Automated source tests and web build do not prove physical-device frame pacing, touch latency, OEM navigation behavior, or exact color reproduction on every display. Native APK installation and physical-device verification are not claimed.
