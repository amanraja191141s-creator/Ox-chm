'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync, spawn } = require('node:child_process');
const http = require('node:http');
const os = require('node:os');
const vm = require('node:vm');
const ROOT = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(ROOT, p), 'utf8');

function request(port, method, pathname) {
  return new Promise((resolve, reject) => {
    const req = http.request({ hostname: '127.0.0.1', port, method, path: pathname }, res => {
      const chunks = []; res.on('data', c => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks).toString() }));
    });
    req.on('error', reject); req.end();
  });
}

test('JavaScript files parse cleanly', () => {
  for (const file of ['assets/js/app.js', 'assets/js/localization.js', 'assets/js/currency-localized-names.js', 'assets/js/theme-bootstrap.js', 'server.js', 'service-worker.js']) {
    const result = spawnSync(process.execPath, ['--check', path.join(ROOT, file)], { encoding: 'utf8' });
    assert.equal(result.status, 0, `${file}: ${result.stderr}`);
  }
});

test('scientific calculator parser passes arithmetic, functions, implicit multiplication and rejection cases', () => {
  const source = read('assets/js/app.js');
  const start = source.indexOf('function evaluateArithmetic(');
  assert.notEqual(start, -1, 'calculator parser not found');
  const open = source.indexOf('{', start); let depth = 0, end = -1;
  for (let i = open; i < source.length; i++) {
    if (source[i] === '{') depth++;
    else if (source[i] === '}' && --depth === 0) { end = i + 1; break; }
  }
  assert.ok(end > open, 'could not isolate parser function');
  const context = {
    STATE: {},
    normalizeStandaloneScientificEntry: value => value,
    normalizeScientificExpressionGlyphs: value => value,
    Math, Number
  };
  vm.runInNewContext(`${source.slice(start, end)};globalThis.evaluateArithmetic=evaluateArithmetic;`, context);
  const calc = context.evaluateArithmetic;
  const near = (actual, expected, epsilon = 1e-10) => assert.ok(Math.abs(actual - expected) <= epsilon, `${actual} != ${expected}`);
  near(calc('2+3*4'), 14);
  near(calc('sin(pi/6)', true, 'rad'), 0.5);
  near(calc('2pi'), 2 * Math.PI);
  near(calc('sqrt(81)'), 9);
  near(calc('√9'), 3);
  near(calc('200+10%'), 220);
  near(calc('2^3^2'), 512);
  assert.throws(() => calc('1/0'));
  assert.throws(() => calc('alert(1)'));
  assert.throws(() => calc('1+('));
});

test('HTML IDs are unique and literal getElementById references resolve or are documented optional', () => {
  const html = read('index.html');
  const ids = [...html.matchAll(/\bid=["']([^"']+)["']/g)].map(m => m[1]);
  const duplicates = ids.filter((id, i) => ids.indexOf(id) !== i);
  assert.deepEqual([...new Set(duplicates)], []);
  const source = read('assets/js/app.js');
  const refs = [...source.matchAll(/getElementById\(['"]([^'"]+)/g)].map(m => m[1]);
  const missing = [...new Set(refs.filter(id => !ids.includes(id)))];
  assert.deepEqual(missing, ['unit-all-results', 'setting-telemetry']);
  assert.match(source, /if\s*\(list\)\s*list\.replaceChildren\(\)/);
});

test('release version is consistent across app metadata and UI', () => {
  assert.equal(JSON.parse(read('package.json')).version, '1.98.65-v98.63.9.17');
  assert.equal(JSON.parse(read('manifest.webmanifest')).version, '1.98.65-v98.63.9.17');
  assert.match(read('index.html'), /1\.98\.65-v98\.63\.9\.17/);
  assert.match(read('index.html'), /SA Calculator/);
  assert.match(read('server.js'), /Static development server/);
  assert.match(read('service-worker.js'), /sa-calculator-v98-63-10-clean-runtime-v9863917/);
});

test('currency cache is restored once during startup through the currency initializer', () => {
  const source = read('assets/js/app.js');
  const domReadyStart = source.indexOf("document.addEventListener('DOMContentLoaded'");
  const domReadyEnd = source.indexOf("\n});", domReadyStart);
  assert.ok(domReadyStart >= 0 && domReadyEnd > domReadyStart, 'DOMContentLoaded initializer not found');
  const startup = source.slice(domReadyStart, domReadyEnd);
  assert.doesNotMatch(startup, /\bloadCachedCurrencyRates\s*\(/, 'startup must not load the same cache before initCurrencies');
  const initStart = source.indexOf('function initCurrencies()');
  const initEnd = source.indexOf('\n}', initStart);
  assert.ok(initStart >= 0 && initEnd > initStart, 'currency initializer not found');
  assert.match(source.slice(initStart, initEnd), /loadCachedCurrencyRates\s*\(/, 'currency initializer must restore cached rates before calculating');
});

test('feedback reports use the current release version rather than stale hard-coded metadata', () => {
  const app = read('assets/js/app.js');
  assert.match(app, /const APP_VERSION = '1\.98\.65-v98\.63\.9\.17'/);
  assert.equal((app.match(/Version: \$\{APP_VERSION\}/g) || []).length, 2);
  assert.doesNotMatch(app, /1\.87\.0-v87/);
});

test('Math Lab feature is fully removed and app is rebranded', () => {
  const html = read('index.html');
  const app = read('assets/js/app.js');
  const css = read('assets/css/app.css') + read('assets/css/app.css');
  assert.doesNotMatch(html, /Math Lab|mathlab|screen-advanced|advanced\.js/i);
  assert.doesNotMatch(app, /Advanced Math Lab|screen-advanced|data-screen.*advanced/i);
  assert.doesNotMatch(css, /#screen-advanced|mathlab-keyboard|advanced-hero/);
  assert.equal(fs.existsSync(path.join(ROOT, 'assets/js/advanced.js')), false);
  assert.equal(fs.existsSync(path.join(ROOT, 'assets/brand/sa-calculator-icon.png')), true);
  assert.match(read('manifest.webmanifest'), /sa-calculator-icon\.png/);
  assert.match(read('manifest.webmanifest'), /SA Calculator/);
});

test('runtime and service-worker precache assets exist', () => {
  const html = read('index.html');
  for (const asset of ['assets/js/theme-bootstrap.js', 'assets/js/localization.js', 'assets/js/currency-localized-names.js', 'assets/js/app.js', 'assets/css/app.css']) {
    assert.ok(fs.existsSync(path.join(ROOT, asset)), `missing ${asset}`);
    assert.ok(html.includes(asset), `index.html does not reference ${asset}`);
  }
  const sw = read('service-worker.js');
  const list = sw.match(/const ASSETS=\[(.*?)\];/s);
  assert.ok(list, 'service worker ASSETS list not found');
  for (const [, asset] of list[1].matchAll(/'([^']+)'/g)) {
    const local = asset === './' ? 'index.html' : asset.replace(/^\.\//, '');
    assert.ok(fs.existsSync(path.join(ROOT, local)), `precache asset missing: ${asset}`);
  }
});


test('PWA offline shell is registered safely and logo MIME type is explicit', () => {
  const app = read('assets/js/app.js');
  const server = read('server.js');
  assert.match(app, /navigator\.serviceWorker\.register\('\.\/service-worker\.js'/);
  assert.match(app, /updateViaCache:\s*'none'/);
  assert.match(server, /'\.png':\s*'image\/png'/);
  assert.match(read('service-worker.js'), /sa-calculator-v98-63-10-clean-runtime-v9863917/);
});

test('IP hygiene: no competitor brand strings and user-provided logo is the only brand image', () => {
  const files = ['index.html', 'assets/js/app.js', 'assets/css/app.css', 'server.js', 'README.md', 'manifest.webmanifest'];
  for (const file of files) assert.doesNotMatch(read(file), /clevcalc|cleveni/i, `${file} contains competitor branding`);
  const brandFiles = fs.readdirSync(path.join(ROOT, 'assets/brand')).filter(name => !name.startsWith('.'));
  assert.deepEqual(brandFiles.sort(), ['android-icons', 'sa-calculator-192.png', 'sa-calculator-512.png', 'sa-calculator-home-logo.svg', 'sa-calculator-icon.png', 'sa-home-neon-wave.svg']);
  assert.ok(fs.statSync(path.join(ROOT, 'assets/brand/sa-calculator-icon.png')).isFile());
});


test('currency converter retains offline-first estimate rates and clearly labels them', () => {
  const source = read('assets/js/app.js');
  const stateStart = source.indexOf('const STATE = {');
  const stateEnd = source.indexOf('\n};', stateStart) + 3;
  assert.ok(stateStart >= 0 && stateEnd > stateStart, 'STATE declaration not found');
  const builtinStart = source.indexOf('const BUILTIN_CURRENCY_RATES =', stateEnd);
  const builtinEnd = source.indexOf(';', builtinStart) + 1;
  const loadStart = source.indexOf('function loadCachedCurrencyRates()');
  const loadOpen = source.indexOf('{', loadStart); let depth = 0, loadEnd = -1;
  for (let i = loadOpen; i < source.length; i++) {
    if (source[i] === '{') depth++;
    else if (source[i] === '}' && --depth === 0) { loadEnd = i + 1; break; }
  }
  assert.ok(builtinStart >= 0 && builtinEnd > builtinStart && loadEnd > loadOpen);
  const context = {
    Object, Number, Date,
    STATE: { currencies: { USD: 1, INR: 94.7 }, currencyUpdatedAt: null, currencyRateDate: null, currencyRateSource: 'built-in' },
    localStorage: { getItem: () => null }
  };
  vm.runInNewContext(`${source.slice(builtinStart, builtinEnd)};${source.slice(loadStart, loadEnd)};globalThis.load=loadCachedCurrencyRates;`, context);
  assert.equal(context.load(), false);
  assert.equal(context.STATE.currencyRateSource, 'built-in fallback');
  assert.equal(context.STATE.currencies.USD, 1);
  assert.equal(context.STATE.currencies.INR, 94.7);
  assert.match(source, /Built-in estimate rates · live refresh unavailable/);
  assert.match(source, /Offline · showing built-in estimate rates/);
});

test('currency providers use current documented endpoints and validate rate freshness', () => {
  const app = read('assets/js/app.js');
  assert.match(app, /@fawazahmed0\/currency-api@latest\/v1\/currencies\/usd\.min\.json/);
  assert.match(app, /latest\.currency-api\.pages\.dev\/v1\/currencies\/usd\.min\.json/);
  assert.match(app, /api\.frankfurter\.dev\/v2\/rates\?base=USD/);
  assert.doesNotMatch(app, /api\.frankfurter\.dev\/v1\//);
  assert.match(app, /normalizeFrankfurterV2Rates/);
  assert.match(app, /validateCurrencyRateDate/);
  assert.match(app, /rate data is stale or future-dated/);
  assert.match(app, /time_last_update_utc/);
});

test('currency date validation rejects impossible dates and Frankfurter validates each row date independently', () => {
  const source = read('assets/js/app.js');
  function extract(name) {
    const start = source.indexOf(`function ${name}(`);
    assert.notEqual(start, -1, `${name} not found`);
    const open = source.indexOf('{', start); let depth = 0;
    for (let i = open; i < source.length; i++) {
      if (source[i] === '{') depth++;
      else if (source[i] === '}' && --depth === 0) return source.slice(start, i + 1);
    }
    throw new Error(`Could not extract ${name}`);
  }
  const context = { Date, Number, String, Array, Object, Error, NON_CURRENCY_CODES: new Set() };
  vm.runInNewContext(`${extract('validateCurrencyRateDate')};${extract('normalizeFrankfurterV2Rates')};globalThis.validate=validateCurrencyRateDate;globalThis.normalize=normalizeFrankfurterV2Rates;`, context);
  assert.throws(() => context.validate('2026-02-31', 'test'));
  assert.throws(() => context.validate('not-a-date', 'test'));
  const today = new Date().toISOString().slice(0, 10);
  const old = new Date(Date.now() - 20 * 86400000).toISOString().slice(0, 10);
  const rows = Array.from({ length: 25 }, (_, i) => ({ base: 'USD', quote: String.fromCharCode(65 + Math.floor(i / 26), 65 + (i % 26), 65), rate: 1 + i / 10, date: i < 5 ? old : today }));
  const normalized = context.normalize(rows);
  assert.equal(Object.keys(normalized.rates).length, 21);
  assert.equal(normalized.rateDate, today);
  assert.throws(() => context.normalize(rows.slice(0, 5)));
});

test('CSS has balanced braces and no obvious top-level syntax break', () => {
  const css = read('assets/css/app.css') + read('assets/css/app.css');
  let depth = 0, quote = '', comment = false, escaped = false;
  for (let i = 0; i < css.length; i++) {
    const c = css[i], n = css[i + 1];
    if (comment) { if (c === '*' && n === '/') { comment = false; i++; } continue; }
    if (quote) { if (escaped) escaped = false; else if (c === '\\') escaped = true; else if (c === quote) quote = ''; continue; }
    if (c === '/' && n === '*') { comment = true; i++; continue; }
    if (c === '"' || c === "'") { quote = c; continue; }
    if (c === '{') depth++;
    if (c === '}') { depth--; assert.ok(depth >= 0, 'unexpected closing CSS brace'); }
  }
  assert.equal(depth, 0, 'unbalanced CSS braces');
  assert.equal(comment, false, 'unterminated CSS comment');
  assert.equal(quote, '', 'unterminated CSS string');
});

test('local server serves app safely and rejects invalid methods/paths', async t => {
  const port = 19000 + Math.floor(Math.random() * 1000);
  const child = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: String(port) }, stdio: 'ignore' });
  t.after(() => child.kill('SIGTERM'));
  let ready = false;
  for (let i = 0; i < 40; i++) {
    try { const r = await request(port, 'GET', '/'); if (r.status === 200) { ready = true; break; } } catch (_) {}
    await new Promise(r => setTimeout(r, 100));
  }
  assert.ok(ready, 'server did not start');
  const home = await request(port, 'GET', '/');
  assert.equal(home.status, 200);
  assert.match(home.headers['content-type'], /text\/html/);
  assert.equal(home.headers['x-content-type-options'], 'nosniff');
  assert.equal((await request(port, 'GET', '/assets/js/app.js')).status, 200);
  assert.equal((await request(port, 'GET', '/assets/brand/sa-calculator-icon.png')).status, 200);
  assert.equal((await request(port, 'GET', '/.env.example')).status, 404);
  assert.equal((await request(port, 'GET', '/..%2f..%2fetc%2fpasswd')).status, 403);
  const post = await request(port, 'POST', '/'); assert.equal(post.status, 405); assert.equal(post.headers.allow, 'GET, HEAD');
  const head = await request(port, 'HEAD', '/'); assert.equal(head.status, 200); assert.equal(head.body, '');
});


test('service worker never caches same-origin API responses', () => {
  const sw = read('service-worker.js');
  assert.match(sw, /url\.pathname\.startsWith\('\/api\/'\)\)return/);
  assert.match(sw, /Never cache API responses/);
});


test('currency refresh count uses only the selectable catalogue, not every provider key', () => {
  const app = read('assets/js/app.js');
  assert.match(app, /function getSupportedCurrencyRateCount\(rates = STATE\.currencies\)/);
  assert.match(app, /getSupportedCurrencyRateCount\(STATE\.currencies\)/);
  assert.match(app, /supportedRateCount} of \${catalogCount} supported currencies/);
});

test('Frankfurter provider metadata never leaks object stringification into currency labels', () => {
  const app = read('assets/js/app.js');
  assert.match(app, /rateSources\[code\] = 'Frankfurter v2'/);
  assert.match(app, /typeof value === 'string'/);
  assert.doesNotMatch(app, /row\.providers\.join/);
});

test('legacy cached Frankfurter object metadata is sanitized before it reaches the UI', () => {
  const app = read('assets/js/app.js');
  assert.match(app, /function sanitizeCurrencySourceLabel\(value\)/);
  assert.match(app, /sanitizeCurrencySourceLabel\(v\) \|\| 'cached'/);
  assert.match(app, /source\.split/);
});

test('manual refresh control is nested inside converter and not global toolbar', () => {
  const html = read('index.html');
  const header = html.slice(html.indexOf('<header class=\"app-header\"'), html.indexOf('</header>'));
  assert.doesNotMatch(header, /btn-refresh-rates/);
  const currency = html.slice(html.indexOf('id=\"screen-currencies\"'));
  assert.match(currency, /class=\"currency-refresh-toolbar\"[\s\S]*?id=\"btn-refresh-rates\"/);
});

test('currency screen excludes charts and saved pairs while keeping refresh', () => {
  const html = read('index.html'); const js = read('assets/js/app.js'); const css = read('assets/css/app.css') + read('assets/css/app.css');
  assert.doesNotMatch(html, /Rate history|Save pair|Load chart|Saved currency pairs|currency-history-chart|currency-watchlist/);
  assert.doesNotMatch(js, /loadCurrencyHistory|renderCurrencyHistory|readCurrencyWatchlist|CURRENCY_HISTORY_CACHE_KEY|CURRENCY_WATCHLIST_KEY/);
  assert.doesNotMatch(css, /\.currency-insights|\.currency-history-chart|\.currency-watchlist/);
  assert.match(html, /id="screen-currencies"[\s\S]*?id="btn-refresh-rates"[^>]*aria-label="Refresh currency rates"/);
  const appHeader = html.slice(html.indexOf('<header class="app-header"'), html.indexOf('</header>'));
  assert.doesNotMatch(appHeader, /btn-refresh-rates/);
  assert.match(js, /refreshCurrencyRates\(false\)/); assert.match(js, /60 \* 60 \* 1000/);
  assert.match(js, /addEventListener\('online'/); assert.match(js, /addEventListener\('visibilitychange'/);
});

test('all calculator screens are registered in favorites and all HTML actions have handlers', () => {
  const html = read('index.html');
  const app = read('assets/js/app.js');
  const screens = [...html.matchAll(/id="screen-([a-z0-9_-]+)"/g)].map(m => m[1]).filter(id => id !== 'viewport' && id !== 'settings' && id !== 'favorites' && id !== 'tools');
  const block = app.slice(app.indexOf('const ALL_CALC_ITEMS'), app.indexOf('function initFavoritesManager'));
  const registered = [...block.matchAll(/\{ id: '([^']+)', name:/g)].map(m => m[1]);
  assert.deepEqual([...new Set(screens)].sort(), [...new Set(registered)].sort());
  const actions = [...new Set([...html.matchAll(/data-action="([A-Za-z_$][\w$]*)"/g)].map(m => m[1]))];
  const missing = actions.filter(name => !new RegExp(`function\\s+${name}\\s*\\(`).test(app));
  assert.deepEqual(missing, []);
  assert.equal((html.match(/class="settings-group-title"/g) || []).length, 12);
  assert.equal((html.match(/class="theme-option"/g) || []).length, 1);
});

test('settings storage validates enumerated preferences and navigation language scope is explicit', () => {
  const app = read('assets/js/app.js');
  assert.match(app, /\['small', 'medium', 'large'\]\.includes\(s\.fontSize\)/);
  assert.match(app, /\['auto', '0', '2', '4', '6'\]\.includes\(String\(s\.precision\)\)/);
  assert.match(app, /\[25, 50, 100, 500\]\.includes\(Number\(s\.maxHistory\)\)/);
  assert.match(read('index.html'), /Navigation Language/);
  assert.match(read('index.html'), /Appearance Mode/);
  assert.match(read('index.html'), /id="setting-theme" data-action="applySettingTheme"/);
  assert.doesNotMatch(read('index.html').match(/<select class="settings-select theme-state-select" id="setting-theme"[\s\S]*?<\/select>/)?.[0] || '', /hidden/);
  assert.doesNotMatch(read('index.html'), /tool instructions remain in English/);
  assert.match(app, /TRANSLATIONS\?\.\[STATE\.language\]\?\.\[screenId\]/);
});

test('settings load restores every preference before writing normalized storage', () => {
  const app = read('assets/js/app.js');
  function extract(name) {
    const start = app.indexOf(`function ${name}(`); assert.notEqual(start, -1);
    const open = app.indexOf('{', start); let depth = 0;
    for (let i = open; i < app.length; i++) { if (app[i] === '{') depth++; else if (app[i] === '}' && --depth === 0) return app.slice(start, i + 1); }
    throw new Error(`Could not extract ${name}`);
  }
  const stored = {theme:'dark',accentColor:'#00897b',oledBlack:true,fontSize:'large',precision:'4',separator:'space',angle:'rad',language:'hi',hapticEnabled:false,vibeStrength:'heavy',keySound:false,autoCopy:true,liveCalc:false,implicitMult:false,trailingZeros:false,startupScreen:'worldtime',restoreState:false,recordHistory:false,maxHistory:100,favorites:['calc','worldtime'],telemetry:true};
  const storage = { value: JSON.stringify(stored), getItem(){return this.value;}, setItem(_key,value){this.value=value;} };
  const elements = new Map();
  const get = id => { if(!elements.has(id)) elements.set(id,{value:'',checked:false}); return elements.get(id); };
  const state = {theme:'light',accentColor:'#1765f5',oledBlack:false,fontSize:'medium',precision:'auto',thousandsSep:'comma',language:'en',hapticEnabled:true,vibeStrength:'medium',keySound:true,autoCopy:false,liveCalc:true,implicitMult:true,trailingZeros:true,startupScreen:'calc',restoreState:true,recordHistory:true,maxHistory:'50',telemetry:false,favorites:['calc']};
  const context = {
    STATE:state, localStorage:storage, document:{getElementById:get}, Object, Array, Number, String, JSON, Math,
    TRANSLATIONS:{en:{},hi:{}}, ALL_CALC_ITEMS:['calc','worldtime'].map(id=>({id})),
    updateDrawerFavoritesDOM(){}, switchScreen(){},
    applySettingTheme(v){state.theme=v;context.saveSettingsToStorage();},
    applyAccentColor(v){state.accentColor=v;context.saveSettingsToStorage();},
    toggleOLED(v){state.oledBlack=v;context.saveSettingsToStorage();},
    applyFontSize(v){state.fontSize=v;context.saveSettingsToStorage();},
    applySettingPrecision(v){state.precision=v;context.saveSettingsToStorage();},
    applySettingSeparator(v){state.thousandsSep=v;context.saveSettingsToStorage();},
    applyLanguage(v){state.language=v;context.saveSettingsToStorage();}
  };
  vm.runInNewContext(`let isLoadingSettings=false;${extract('saveSettingsToStorage')};${extract('loadSettingsFromStorage')};globalThis.saveSettingsToStorage=saveSettingsToStorage;globalThis.loadSettingsFromStorage=loadSettingsFromStorage;`,context);
  context.loadSettingsFromStorage();
  const saved = JSON.parse(storage.value);
  assert.equal(state.hapticEnabled,false);
  assert.equal(state.autoCopy,true);
  assert.equal(state.liveCalc,false);
  assert.equal(state.startupScreen,'worldtime');
  assert.equal(state.maxHistory,'100');
  assert.deepEqual(Array.from(state.favorites),['calc','worldtime']);
  assert.equal(saved.hapticEnabled,false);
  assert.equal(saved.autoCopy,true);
  assert.equal(saved.liveCalc,false);
  assert.equal(saved.startupScreen,'worldtime');
  assert.equal(saved.maxHistory,'100');
  assert.deepEqual(Array.from(saved.favorites),['calc','worldtime']);
});

test('history retention keeps protected entries and restore sanitizes persisted records', () => {
  const source = read('assets/js/app.js');
  function extract(name) {
    const start = source.indexOf(`function ${name}(`);
    assert.notEqual(start, -1);
    const open = source.indexOf('{', start); let depth = 0;
    for (let i = open; i < source.length; i++) {
      if (source[i] === '{') depth++;
      else if (source[i] === '}' && --depth === 0) return source.slice(start, i + 1);
    }
    throw new Error(`Could not extract ${name}`);
  }
  const storage = { value: JSON.stringify([
    {expr:'1+1',res:'2',locked:false},
    {expr:'2+2',res:'4',locked:true},
    {expr:'3+3',res:'6',locked:false},
    {expr:'4+4',res:'8',locked:true},
    {expr:'5+5',res:'10',locked:false},
    {expr:'x'.repeat(251),res:'bad'}
  ]) };
  const context = { STATE:{history:[],maxHistory:'3'}, Number, Math, Set, JSON, String, localStorage:{getItem:()=>storage.value,setItem:(_k,v)=>{storage.value=v;}} };
  vm.runInNewContext(`${extract('trimHistoryToLimit')};${extract('persistHistory')};${extract('restoreHistory')};globalThis.restore=restoreHistory;`,context);
  context.restore();
  assert.deepEqual(Array.from(context.STATE.history, item=>item.expr), ['2+2','4+4','5+5']);
  assert.equal(context.STATE.history.filter(item=>item.locked).length,2);
});

test('history writer refuses new records when all configured slots are protected', () => {
  const source = read('assets/js/app.js');
  function extract(name) {
    const start = source.indexOf(`function ${name}(`); assert.notEqual(start, -1);
    const open = source.indexOf('{', start); let depth = 0;
    for (let i = open; i < source.length; i++) { if (source[i] === '{') depth++; else if (source[i] === '}' && --depth === 0) return source.slice(start, i + 1); }
    throw new Error(`Could not extract ${name}`);
  }
  const state = { recordHistory: true, maxHistory: '2', history: [{expr:'a',res:'1',locked:true},{expr:'b',res:'2',locked:true}] };
  let toast = '';
  const context = { STATE: state, Number, Math, String, showToast: value => { toast = value; }, trimHistoryToLimit(){}, persistHistory(){}, updateHistoryDOM(){} };
  vm.runInNewContext(`${extract('recordHistoryEntry')};globalThis.record=recordHistoryEntry;`, context);
  assert.equal(context.record('c', '3'), false);
  assert.equal(state.history.length, 2);
  assert.match(toast, /All history slots are protected/);
});

test('help and feedback controls open real local dialogs without automatic upload', () => {
  const html = read('index.html'); const app = read('assets/js/app.js');
  assert.match(html, /id="help-modal"[^>]*role="dialog"/);
  assert.match(html, /id="feedback-modal"[^>]*role="dialog"/);
  assert.match(html, /Nothing is sent automatically/);
  assert.match(app, /function initSupportDialogs\(\)/);
  assert.match(app, /function shareFeedbackReport\(\)/);
  assert.match(app, /navigator\.share\(\{ title: 'SA Calculator feedback', text: report \}\)/);
  assert.match(app, /initSupportDialogs\(\)/);
});

test('drawer localization preserves its accessible title and updates language metadata', () => {
  const app = read('assets/js/app.js');
  assert.match(app, /getElementById\('drawer-dialog-title'\)/);
  assert.match(app, /document\.documentElement\.lang = lang/);
  assert.match(app, /item\.setAttribute\('aria-label', dict\[sId\]\)/);
});

test('history max-entry limit never evicts protected entries', () => {
  const source = read('assets/js/app.js');
  const start = source.indexOf('function trimHistoryToLimit(');
  const open = source.indexOf('{', start); let depth = 0, end = -1;
  for (let i = open; i < source.length; i++) {
    if (source[i] === '{') depth++;
    else if (source[i] === '}' && --depth === 0) { end = i + 1; break; }
  }
  const context = { STATE: { maxHistory: '2', history: [
    {expr:'1',res:'1',locked:true}, {expr:'2',res:'2',locked:true},
    {expr:'3',res:'3',locked:true}, {expr:'4',res:'4',locked:false}
  ] }, Number, Math, Set };
  vm.runInNewContext(`${source.slice(start,end)};trimHistoryToLimit();`, context);
  assert.deepEqual(Array.from(context.STATE.history, item => item.expr), ['1','2','3']);
});

test('currency refresh timestamp is visible, localized, and saved after every completed attempt', () => {
  const html = read('index.html');
  const app = read('assets/js/app.js');
  const css = read('assets/css/app.css') + read('assets/css/app.css');
  assert.match(html, /id="cur-refresh-time"/);
  assert.match(app, /function renderCurrencyRefreshTimes\(/);
  assert.match(app, /function saveCurrencyRefreshMeta\(/);
  assert.match(app, /STATE\.currencyLastRefreshAt = Date\.now\(\);\s*saveCurrencyRefreshMeta\(\);/);
  assert.match(app, /STATE\.currencyLastSuccessfulRefreshAt = STATE\.currencyUpdatedAt/);
  assert.match(css, /\.currency-refresh-time/);
  assert.match(app, /Last checked: \$\{checked\} · Rates last updated: \$\{updated\}/);
});


test('currency refresh evaluates all dated providers and prioritizes timestamped fresher data', () => {
  const app = read('assets/js/app.js');
  const start = app.indexOf('async function fetchCurrencyRateBundle(');
  const end = app.indexOf('function getCurrencyPairSources(', start);
  assert.ok(start >= 0 && end > start, 'currency provider pipeline must exist');
  const pipeline = app.slice(start, end);
  assert.ok(pipeline.indexOf("name:'Frankfurter v2'") < pipeline.indexOf("name:'Open ER-API'") && pipeline.indexOf("name:'Open ER-API'") < pipeline.indexOf("name:'Fawaz Exchange API'"), 'Frankfurter is the primary public API, followed by independent public fallbacks');
  assert.doesNotMatch(pipeline, /if\s*\(combined\s*&&\s*missing\(\)\.length\s*===\s*0\)\s*break/, 'a complete older provider must not stop newer providers from being checked');
  assert.match(app, /incomingDate\s*<\s*currentDate/, 'older observations must not roll back newer per-currency rates');
  assert.match(app, /time_last_update_utc/, 'Open ER-API provider observation date must come from its response timestamp');
  assert.match(app, /validateCurrencyRateDate\(updated\.toISOString\(\)\.slice\(0,10\)/, 'provider timestamp must be validated as an observation date');
});

test('header uses screen-specific translated titles and SA Calculator only on the basic calculator', () => {
  const html = read('index.html');
  const header = html.match(/<header class="app-header">([\s\S]*?)<\/header>/)?.[1] || '';
  assert.match(header, /id="app-title">SA Calculator</);
  assert.match(header, /<img class="brand-mark" src="assets\/brand\/sa-calculator-home-logo\.svg"/);
  const app = read('assets/js/app.js');
  assert.match(app, /setElementText\('app-title', screenId === 'calc' \|\| screenId === 'tools' \? 'SA Calculator' : translatedTitle\)/);
  assert.match(app, /const currentScreenTitle = dict\[currentTitleKey\] \|\| \(STATE\.currentScreen === 'calc' \? 'SA Calculator' : STATE\.currentScreen\)/);
  assert.match(app, /setElementText\('app-title', currentScreenTitle\)/);
  assert.match(app, /currencies: 'Currency Converter'/);
  assert.match(app, /units: 'Unit Converter'/);
  assert.match(app, /settings: 'Settings'/);
});

test('settings screen retains all twelve documented groups and unique control IDs', () => {
  const html = read('index.html');
  const settings = html.match(/<div class="screen" id="screen-settings">([\s\S]*?)<\/div>\s*<\/div> <!-- END VIEWPORT -->/)?.[1] || '';
  const groups = [...settings.matchAll(/class="settings-group-title"/g)];
  assert.equal(groups.length, 12);
  const ids = [...settings.matchAll(/\bid="(setting-[^"]+)"/g)].map(m => m[1]);
  assert.equal(ids.length, new Set(ids).size);
  for (const id of ['setting-fontsize','setting-theme','setting-accent','setting-oled','setting-livecalc','setting-implicit','setting-precision','setting-separator','setting-trailing-zero','setting-language','setting-startup-screen','setting-restore-state','setting-record-history','setting-max-history','setting-autocopy','setting-sound','setting-haptic','setting-vibe-strength']) assert.ok(ids.includes(id), `missing ${id}`);
  assert.match(settings, /<input type=\"hidden\" id=\"setting-accent\"/, 'legacy accent state remains available for saved settings while the duplicate visible selector is removed');
  assert.doesNotMatch(settings, /Accent Highlight Color|setting-telemetry|Diagnostics \(local only\)|Project Status/, 'duplicate accent and inert status controls are removed');
  assert.doesNotMatch(html, /drawer-section-hint|SMART COMPARISON/, 'decorative drawer and tool intro copy is removed');
});

test('private Cloudflare currency API is removed and public global providers are configured', () => {
  const fs = require('node:fs');
  const path = require('node:path');
  const appRoot = path.resolve(__dirname, '..');
  const appJs = fs.readFileSync(path.join(appRoot, 'assets/js/app.js'), 'utf8');
  const html = fs.readFileSync(path.join(appRoot, 'index.html'), 'utf8');
  const pipelineStart = appJs.indexOf('async function fetchCurrencyRateBundle(');
  const pipelineEnd = appJs.indexOf('function getCurrencyPairSources(', pipelineStart);
  const pipeline = appJs.slice(pipelineStart, pipelineEnd);
  assert.ok(pipeline.indexOf("name:'Frankfurter v2'") < pipeline.indexOf("name:'Open ER-API'"));
  assert.ok(pipeline.indexOf("name:'Open ER-API'") < pipeline.indexOf("name:'Fawaz Exchange API'"));
  assert.doesNotMatch(appJs, /SA_CURRENCY_API_URL|normalizePrivateSaCurrencyRates|SA Currency API/);
  assert.doesNotMatch(html, /private-currency-api-config|cloud-api/i);
  assert.equal(fs.existsSync(path.join(appRoot, 'assets/js/private-currency-api-config.js')), false);
  assert.equal(fs.existsSync(path.join(appRoot, '..', 'cloud-api')), false);
});


test('dynamic option picker clears stale active-descendant references before rendering', () => {
  const app = read('assets/js/app.js');
  const start = app.indexOf('function updateHighlight(scroll)');
  const end = app.indexOf('function openPicker(select)', start);
  assert.ok(start >= 0 && end > start);
  assert.match(app.slice(start, end), /optionList\.removeAttribute\('aria-activedescendant'\)/);
});

test('transient app toast is announced accessibly without taking focus', () => {
  const html = read('index.html');
  assert.match(html, /<div id="app-toast"[^>]*role="status"[^>]*aria-live="polite"[^>]*aria-atomic="true"/);
});

test('current release documentation does not claim a private API is shipped', () => {
  const audit = read('MICRO-LEVEL-AUDIT-v98.63.md');
  assert.match(audit, /No private Cloudflare Worker/);
  assert.match(audit, /1\.98\.65-v98\.63\.9\.17/);
  assert.match(read('RELEASE-VERIFICATION.md'), /1\.98\.65-v98\.63\.9\.17/);
});

test('mobile release gate keeps viewport safe-area, narrow-screen and reduced-motion rules', () => {
  const html = read('index.html');
  const css = read('assets/css/app.css') + read('assets/css/app.css');
  assert.match(html, /name="viewport" content="width=device-width, initial-scale=1\.0, viewport-fit=cover, interactive-widget=resizes-content"/);
  assert.match(html, /class="skip-to-workspace" href="#screen-viewport"/);
  assert.match(css, /env\(safe-area-inset-bottom/);
  assert.match(css, /@media\s*\(max-width:\s*360px\)/);
  assert.match(css, /@media\s*\(max-width:\s*380px\)/);
  assert.match(css, /prefers-reduced-motion:\s*reduce/);
});

test('local server CSP permits only the configured public currency provider origins', () => {
  const server = read('server.js');
  for (const origin of [
    'https://cdn.jsdelivr.net',
    'https://latest.currency-api.pages.dev',
    'https://open.er-api.com',
    'https://api.frankfurter.dev'
  ]) assert.ok(server.includes(origin), `CSP missing ${origin}`);
  assert.match(server, /connect-src 'self'/);
  assert.match(server, /frame-ancestors 'none'/);
  assert.match(server, /X-Content-Type-Options/);
});


test('full-app localization ships eight languages, RTL support, accessible text and locale-aware keypad glyphs', () => {
  const html = read('index.html');
  const app = read('assets/js/app.js');
  const loc = read('assets/js/localization.js');
  assert.match(html, /assets\/js\/localization\.js/);
  assert.match(html, /Changes the language of app labels, controls, messages and supported instructions\./);
  assert.match(loc, /supported: \['en', \.\.\.langs\]/);
  for (const lang of ['hi','ur','es','fr','de','ar','zh']) assert.match(loc, new RegExp(`\\b${lang}\\b`));
  assert.match(loc, /document\.documentElement\.dir = \['ar','ur'\]\.includes\(active\) \? 'rtl' : 'ltr'/);
  assert.match(loc, /aria-label/);
  assert.match(loc, /placeholder/);
  assert.match(loc, /Intl\.NumberFormat/);
  assert.match(loc, /data-popup/);
  assert.match(app, /globalThis\.SALocalization\.apply\(lang\)/);
});

test('localization dictionary returns language-specific phrases and native digits without changing canonical input values', () => {
  const source = read('assets/js/localization.js');
  const context = { window: {}, document: {}, Intl };
  vm.runInNewContext(source, context);
  const localization = context.window.SALocalization;
  assert.deepEqual(Array.from(localization.supported), ['en','hi','ur','es','fr','de','ar','zh']);
  assert.equal(localization.translate('Settings', 'hi'), 'सेटिंग्स');
  assert.equal(localization.translate('Settings', 'es'), 'Ajustes');
  assert.equal(localization.translate('Currency Converter', 'fr'), 'Convertisseur de devises');
  assert.equal(localization.translate('Settings', 'de'), 'Einstellungen');
  assert.equal(localization.translate('Settings', 'zh'), '设置');
  assert.equal(localization.translate('Search currency', 'hi'), 'मुद्रा खोजें');
  assert.equal(localization.translate('Maximum 15 digits allowed', 'hi'), 'अधिकतम १५ अंक अनुमत हैं');
  assert.equal(localization.translate('12345678.90', 'hi'), '१,२३,४५,६७८.९०');
  assert.equal(localization.localizeDigits('1234567890', 'hi'), '१२३४५६७८९०');
  assert.equal(localization.localizeDigits('1234567890', 'ar'), '١٢٣٤٥٦٧٨٩٠');
  assert.equal(localization.translate('SA Calculator', 'hi'), 'SA Calculator');
});


test('localization translates input attributes and tracks fresh dynamic text without stale node restoration', () => {
  const loc = read('assets/js/localization.js');
  assert.match(loc, /const renderedText = new WeakMap\(\)/);
  assert.match(loc, /saved\[attr\] = \{ source: current, rendered: undefined \}/);
  assert.match(loc, /\['aria-label','title','placeholder'\]\.forEach/);
  assert.doesNotMatch(loc, /if \(\!\(el instanceof Element\)\) return;[\s\S]{0,100}input,textarea,script,style,code/);
  const app = read('assets/js/app.js');
  assert.match(app, /new Intl\.DisplayNames\(\[locale\], \{ type: 'currency', fallback: 'code' \}\)/);
  assert.match(app, /refreshCurrencyLocalization\(\)/);
  assert.match(app, /SALocalization\?\.locale \|\| undefined/);
});


test('initial localization source rows provide seven non-empty translations', () => {
  const source = read('assets/js/localization.js');
  const start = source.indexOf('const rows = {');
  const end = source.indexOf('\n  };', start);
  assert.ok(start >= 0 && end > start);
  const lines = source.slice(start, end).split('\n').filter(line => /^    '.*':\[.*\],?$/.test(line));
  assert.equal(lines.length, 188);
  for (const line of lines) {
    const values = line.match(/:\[(.*)\],?$/)?.[1]?.match(/'(?:[^']*)'/g) || [];
    assert.equal(values.length, 7, `expected seven language values: ${line.slice(0, 80)}`);
    assert.ok(values.every(value => value.length > 2));
  }
});

test('bundled CLDR currency names cover every selectable currency in all seven translated locales', () => {
  const names = read('assets/js/currency-localized-names.js');
  assert.match(names, /window\.SA_CURRENCY_LOCALIZED_NAMES/);
  const app = read('assets/js/app.js');
  assert.match(app, /SA_CURRENCY_LOCALIZED_NAMES\?\.\[language\]\?\.\[normalized\]/);
  assert.match(read('service-worker.js'), /currency-localized-names\.js/);
});

test('localization supports plural-sensitive date countdowns and parameterized currency refresh status', () => {
  const loc = read('assets/js/localization.js');
  assert.match(loc, /function formatCount\(key, count, lang = active\)/);
  assert.match(loc, /new Intl\.PluralRules\(locale\)/);
  assert.ok(loc.includes('Last checked: (.*?) · Rates last updated:'));
  assert.match(read('assets/js/app.js'), /days > 0 \? 'left' : 'ago'/);
});

test('every inventoried static HTML text and accessibility attribute has all seven translations', () => {
  const inventory = JSON.parse(read('tests/localization-inventory.json'));
  const context = { window: {}, document: {}, Intl };
  vm.runInNewContext(read('assets/js/localization.js'), context);
  const loc = context.window.SALocalization;
  assert.equal(inventory.unmatched.length, 0, `untranslated inventory items: ${inventory.unmatched.join(' | ')}`);
  assert.ok(inventory.required.length >= 390, 'visible UI inventory unexpectedly shrank');
  for (const phrase of inventory.required) {
    for (const language of ['hi','ur','es','fr','de','ar','zh']) {
      assert.ok(loc.hasTranslation(phrase, language), `${language} missing: ${phrase}`);
      assert.equal(typeof loc.translate(phrase, language), 'string');
    }
  }
});

test('currency-name fallback has 105 CLDR names in each of the eight supported locales', () => {
  const context = { window: {} };
  vm.runInNewContext(read('assets/js/currency-localized-names.js'), context);
  for (const language of ['en','hi','ur','es','fr','de','ar','zh']) {
    assert.equal(Object.keys(context.window.SA_CURRENCY_LOCALIZED_NAMES[language]).length, 105, `${language} currency names`);
  }
});

test('plural-sensitive date labels follow each selected language instead of English grammar', () => {
  const context = { window: {}, document: {}, Intl };
  vm.runInNewContext(read('assets/js/localization.js'), context);
  const loc = context.window.SALocalization;
  assert.match(loc.translate('1 day left', 'es'), /Queda/);
  assert.match(loc.translate('2 days left', 'es'), /Quedan/);
  assert.match(loc.translate('2 days left', 'ar'), /يومان|أيام/);
  assert.match(loc.translate('2 days ago', 'zh'), /天前/);
});

test('parameterized localization keeps user-supplied values and formats numbers by selected locale', () => {
  const context = { window: {}, document: {}, Intl };
  vm.runInNewContext(read('assets/js/localization.js'), context);
  const loc = context.window.SALocalization;
  assert.match(loc.translate('From currency: USD', 'hi'), /मूल मुद्रा: USD/);
  assert.match(loc.translate('Delete Birthday 2026', 'fr'), /Supprimer Birthday 2026/);
  assert.match(loc.translate('From unit: Kilometer (km)', 'hi'), /स्रोत इकाई: किलोमीटर/);
  assert.match(loc.translate('Last checked: 14/11/2026 · Rates last updated: 13/11/2026', 'de'), /Zuletzt geprüft/);
  assert.match(loc.translate('1234567.89', 'hi'), /१२,३४,५६७/);
  assert.match(loc.translate('1234567.89', 'de'), /1\.234\.567,89/);
});

test('all 76 Unit Converter unit names are localized in all seven translated languages', () => {
  const units = JSON.parse(read('tests/unit-localization-inventory.json'));
  const context = { window: {}, document: {}, Intl };
  vm.runInNewContext(read('assets/js/localization.js'), context);
  const loc = context.window.SALocalization;
  assert.equal(units.length, 76);
  for (const unit of units) for (const language of ['hi','ur','es','fr','de','ar','zh']) {
    assert.ok(loc.hasTranslation(unit, language), `${language} missing unit: ${unit}`);
  }
});

test('dynamic loan schedules, comparison winners and startup screen labels are translated with placeholders intact', () => {
  const context = { window: {}, document: {}, Intl };
  vm.runInNewContext(read('assets/js/localization.js'), context);
  const loc = context.window.SALocalization;
  assert.match(loc.translate('2 monthly payments · 1 interest-only months · Equal principal', 'hi'), /मासिक भुगतान/);
  assert.match(loc.translate('Items A, B (Equal lowest unit price)', 'fr'), /Articles A, B/);
  assert.match(loc.translate('Default startup screen: Currency Converter', 'de'), /Standard-Startbildschirm: Währungsrechner/);
});

test('merged localization catalogue has more than 600 complete translation keys across seven languages', () => {
  const context = { window: {}, document: {}, Intl };
  vm.runInNewContext(read('assets/js/localization.js'), context);
  const loc = context.window.SALocalization;
  assert.ok(loc.catalogueKeys.length >= 600, `catalogue only has ${loc.catalogueKeys.length} keys`);
  for (const key of loc.catalogueKeys) for (const language of ['hi','ur','es','fr','de','ar','zh']) {
    assert.ok(loc.hasTranslation(key, language), `${language} missing catalogue key ${key}`);
  }
});

test('all inventoried dynamic message templates have translations in all seven non-English languages', () => {
  const templates = JSON.parse(read('tests/dynamic-localization-inventory.json'));
  const context = { window: {}, document: {}, Intl };
  vm.runInNewContext(read('assets/js/localization.js'), context);
  const loc = context.window.SALocalization;
  for (const template of templates) for (const language of ['hi','ur','es','fr','de','ar','zh']) {
    assert.ok(loc.hasTranslation(template, language), `${language} missing dynamic template: ${template}`);
  }
});
